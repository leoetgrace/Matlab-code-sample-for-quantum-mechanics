function OUN=OUN(gamma,dt,point)
% -----this function is used to generate orstein-Ulenbeck noise z(t).
% gamma is the parameter in O-U noise, dt is time interval, point is the total steps.
% the data returned to main function is a m*2 matrix, m is time point,
% 2 colume can be used as real part and imaginary part.

%THANKS FOR PROF. YU's ORIGINAL PROGRAM. TRANSLATED BY Xinyu at Stevens.
%@copyright ver. 1.0

    k=sqrt(dt)*gamma/sqrt(2);  %such that M(Zt^* Zs)=alpha(t,s)=gamma/2*exp(-gamma|t-s|)
    expdt=exp(-gamma*dt);


    randn('seed',sum(100*clock));  %set random seed
    xi=randn(point,2);  %complex Wiener process
    %xi=(sqrt(gamma)/4)*randn(nf,2);  %complex Wiener process
    Zt=zeros(point,2);  %O-U process: d Zt = -gamma*Zt dt + k*xi

    Zt(1,:)=sqrt(gamma/4)*xi(1,:);
    %Zt(1,:)=[1 1];
    for l=2:point
    %t=(k-1)*dt;
    Zt(l,:)=Zt(l-1,:)*expdt + k*xi(l,:);
    end;
    OUN=Zt;

%Zt
%plot(0:dt:t,Zt(:,1),0:dt:t,Zt(:,2));

%function g: t -> interpolates Zt for all 0 <= t <= Tf 
%gt=Zt(floor(t/dt)+1,:)*(dt*(floor(t/dt)+1)-t)/dt + Zt(floor(t/dt)+2,:)*(t-dt*floor(t/dt))/dt;