function dy=cavmirror_ODE1(t,y)
global wm G r
dy=zeros(4,1);

dy(1)=0.5*r-r*y(1)-1i*y(1)*y(2)+2*wm*y(2)+1i*y(4);
dy(2)=-r*y(2)-2*wm*y(1)-1i*y(2)*y(2);
dy(3)=-r*y(3)+G*y(2)-1i*y(2)*y(3);
dy(4)=-2*r*y(4)-0.5*r*y(2)-1i*y(2)*y(4);
