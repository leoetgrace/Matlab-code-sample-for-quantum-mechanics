%%used to normalize a vector or matrix.%%
%This program is part of the toolbox qoplus
%qoplus is a kind of addones programs designed by Xinyu Zhao based on 
%the original quantum optics toolbox. @copyright Ver 1.00

function Vn=normalize(V)
N=size(V);
if N(2)==N(1)
    Vn=qo(V)/trace(qo(V));
    Vn=unqo(Vn);
else
    Vn=V/sqrt(V'*V);
end