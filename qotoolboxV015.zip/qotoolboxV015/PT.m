function PT=PT(rho)
% This function is used to calculate the partial transposition of the 
% density matrix. The Hilbert space is 2n-dimensional. The partial
% transposition is taken for system A.
% Program by Xinyu at Stevens

PTrho=rho;
N=size(rho);
n=sqrt(N(1));
for ia=1:n
    for jb=1:n
        for ka=1:n
            for lb=1:n
                RowPT=(ia-1)*n+jb;
                ColPT=(ka-1)*n+lb;
                Row=(ka-1)*n+jb;
                Col=(ia-1)*n+lb;
                PTrho(RowPT,ColPT)=rho(Row,Col);
            end
        end
    end
end
      
PT=PTrho;
end
