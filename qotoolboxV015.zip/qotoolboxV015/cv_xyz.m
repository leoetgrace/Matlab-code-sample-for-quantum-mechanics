%main, solving the coupled 2cav stochastic schrodinger eq. @copyright Ver 3.00
clear all
tic;
global a1 a1d a2 a2d w1 w2 la
point=1000;
rep=200;
w1=1;
w2=1;
la=1;
r=2;
cutoff1=10;
cutoff2=10;
t0=0;
tf=10;
dt=(tf-t0)/point;
tspan=linspace(t0,tf,point);

alpha1=1;   %initial state coherent state 1
alpha2=0;   %initial state coherent state 2

%%%%%%%%%% generate creation and annihilation operator %%%%%%%%%%%%%
I1=eye(cutoff1);
I2=eye(cutoff2);

I1_qo=qo(I1);
I2_qo=qo(I2);

a1_qo=destroy(cutoff1);
a1_qo=tensor(a1_qo,I2_qo);
temp=zeros(cutoff1*cutoff2,cutoff1*cutoff2);
temp(:)=a1_qo.data(:);
a1=temp;


a2_qo=destroy(cutoff2);
a2_qo=tensor(I1_qo,a2_qo);
temp=zeros(cutoff1*cutoff2,cutoff1*cutoff2);
temp(:)=a2_qo.data(:);
a2=temp;


a1d=a1';
a1d_qo=a1_qo';
a2d=a2';
a2d_qo=a2_qo';

Hs=w1*a1d*a1+w2*a2d*a2+la*(a1d*a2+a2d*a1);
L1=a1;
L2=a2;
L=a1+a2;
O1=a1;
O2=a2;
I=kron(I1,I2);
%%%%%%%%%% end of generating creation and annihilation operators %%%%%

%%%%% initial state %%%%%
alpha1=1;
D1=exp(-0.5*abs(alpha1)^2)*expm(alpha1*a1d_qo-conj(alpha1)*a1_qo);
% D1=exp(0.5*abs(alpha1)^2)*expm(alpha1*a1d_qo);
mD1=exp(-0.5*abs(-alpha1)^2)*expm(-alpha1*a1d_qo-conj(-alpha1)*a1_qo);
alpha2=1;
D2=exp(-0.5*abs(alpha2)^2)*expm(alpha2*a2d_qo-conj(alpha2)*a2_qo);
vac1=zeros(cutoff1,1);
vac1(1)=1;
vac1_qo=qo(vac1);
vac2=zeros(cutoff2,1);
vac2(1)=1;
vac2_qo=qo(vac2);
vac=kron(vac1,vac2);
vac_qo=tensor(vac1_qo,vac2_qo);


fai0=(D1)*vac_qo;
% fai20=vac2_qo;
% fai10=zeros(cutoff1,1);
% fai20=zeros(cutoff2,1);
% fai10(2)=1;
% fai20(1)=1;
% fai0=tensor(fai10,fai20);
fai0=unqo(fai0);
fai0=normalize(fai0);

% %----using O-U noise
CF=zeros(point,point);
for m=1:point
    t=t0+(m-1)*dt;
    for n=1:point
       s=(n-1)*dt;
       CF(m,n)=(r/2)*exp(-r*abs(t-s));
    end
    CFt(m)=CF(m,1);
end


% % ----using Ohmic CF
% CFt=OhmicCF(wc,kT,t0,tf,point);
% for m=1:point
%     for n=1:point
%         CF(m,n)=CFt(abs(m-n)+1);
%         if m<n
%             CF(m,n)=conj(CF(m,n));
%         end
%     end
% end

F1=zeros(point,1);
f1=zeros(point,point);
F2=zeros(point,1);
f2=zeros(point,point);
for m=1:point
    f1(m,m)=1;
    f2(m,m)=1;
end

for m=2:point
    for n=1:m-1
        df1(m-1,n)=1i*(w1*f1(m-1,n)+la*f2(m-1,n))+F1(m-1)*f1(m-1,n)+F1(m-1)*f2(m-1,n);
        df2(m-1,n)=1i*(w2*f2(m-1,n)+la*f1(m-1,n))+F2(m-1)*f2(m-1,n)+F2(m-1)*f1(m-1,n);
        f1(m,n)=f1(m-1,n)+df1(m-1,n)*dt;
        f2(m,n)=f2(m-1,n)+df2(m-1,n)*dt;
    end
    
    for k=1:m
        F1(m)=F1(m)+f1(m,k)*CF(m,k)*dt;
        F2(m)=F2(m)+f2(m,k)*CF(m,k)*dt;
    end
end


%  F1=0.5*ones(1,point);
%  F2=0.5*ones(1,point);

psi=zeros(cutoff1*cutoff2,point,rep);


randn('seed',sum(100*clock));
for n=1:rep
%--solving O operator

Zt=OUN(r,dt,point);
z=Zt(:,1)+1i*Zt(:,2);

 fai=zeros(cutoff1*cutoff2,point);
 fai(:,1)=fai0;




    psi(:,1,n)=fai0;


    V(:,1)=fai0;
    V0=fai0;
    ztu(1)=z(1);
        mL(1)=V0'*L*V0;
        mLd=V0'*L'*V0;
        L_mL=L-mL(1)*kron(I1,I2);
        Ld_mLd=L'-mLd*kron(I1,I2);
        mLO=0;

    for m=2:6
        Obar=F1(m-1)*O1+F2(m-1)*O2;
        V(:,m)=((-1i*Hs+ztu(m-1)*L_mL-Ld_mLd*Obar+mLO*kron(I1,I2))*V(:,m-1))*0.2*dt+V(:,m-1);
        fai=V(:,m);
        mL(m)=fai'*L*fai;
        mLd(m)=fai'*L'*fai;
        L_mL=L-mL(m)*kron(I1,I2);
        Ld_mLd=L'-mLd(m)*kron(I1,I2);
        mLO=fai'*(Ld_mLd*Obar)*fai;
        int=0;
        for k=1:m
        int=int+conj(CFt(m-k+1))*mLd(k)*dt;
        end
        ztu(m)=z(m)+int;
    end
    
    V(:,2)=V(:,6);
    psi(:,2,n)=V(:,2);
    mL(2)=mL(6);
    mLd(2)=mL(6);
    mLO(2)=mLO;
    ztu(2)=ztu(6);
%     rho(:,:,2,n)=V(:,2)*V(:,2)';
    
    %%%%%%%%% Eular mid-point %%%%%%%%%%%%%%%%%%%%%%%%%%    
    V(:,1)=V0;
%     rho(:,:,1,n)=V0*V0';
    ztu(1)=z(1);
        mL(1)=V0'*L*V0;
        mLd(1)=V0'*L'*V0;
        mLO(1)=0;
%         L_mL=L-mL(1)*eye(4);
%         Ld_mLd=L'-mLd*eye(4);
%         mLO=0;

    for m=3:point
        Obar_2=F1(m-2)*O1+F2(m-2)*O2;
        
        dV_2=(-1i*Hs+ztu(m-2)*(L-mL(m-2)*I)-(L'-mLd(m-2)*I)*Obar_2...
            +mLO(m-2)*I)*V(:,m-2);
        V_1=V(:,m-2)+dt*dV_2;
        mL(m-1)=V_1'*L*V_1;
        mLd(m-1)=V_1'*L'*V_1;
        V_1=V(:,m-2)+dt*dV_2;
        Obar_1=F1(m-1)*O1+F2(m-1)*O2;
        dV_1=(-1i*Hs+ztu(m-1)*(L-mL(m-1)*I)-(L'-mLd(m-1)*I)*Obar_1...
            +mLO(m-1)*I)*V_1;
        V(:,m)=V(:,m-2)+2*dt*dV_1;
        %V(:,m)=((-1i*Hs+ztu(m-1)*L-mL(-Ld_mLd*Obar+mLO*eye(4))*V(:,m-1))*dt+V(:,m-1);
        normV(m)=V(:,m)'*V(:,m);
%         V(:,m)=V(:,m)./normV(m);
        Obar=F1(m)*O1+F2(m)*O2;
        fai=V(:,m);
        mL(m)=fai'*L*fai;
        mLd(m)=fai'*L'*fai;
        mLO(m)=fai'*(L'-mLd(m)*I)*Obar*fai;

        int=0;
        for k=1:m
        int=int+conj(CFt(m-k+1))*mLd(k)*dt;
        end

        ztu(m)=z(m)+int;
        %V(:,m)=V(:,m)/sqrt(normV(m));
        psi(:,m,n)=V(:,m);
%         rho(:,:,m,n)=V(:,m)*V(:,m)';
%         Mo(m)=trace(V(:,m)*V(:,m)');
    end

end

for m=1:point
    rhotemp=zeros(cutoff1*cutoff2,cutoff1*cutoff2);
    for n=1:rep
        temp=psi(:,m,n);
        rhotemp=rhotemp+temp*temp';
    end
%     rho(:,:,m)=rhotemp/rep;
    rho=rhotemp/rep;
    rhoPT=PT(rho);
    EV=eig(rhoPT);
    Neg(m)=max(0,-2*min(EV));
    a1da1(m)=trace(rho*a1d*a1);
    a2da2(m)=trace(rho*a2d*a2);
end


figure
plot(tspan,a1da1,'r'); hold on
%plot(tspan,y1,'r--'); hold on
plot(tspan,Neg,'b'); hold on
plot(tspan,a2da2,'g');
%plot(tspan,y2,'g--'); hold on


toc;


% draw wigner function
% for timepoint=[3,20,40,60,80,100,120,140,160,180,200,220,240]
% 
% xvec=[-100:100]/100*4;
% yvec=xvec;
% dim=vac_qo.dims;
% psiqo=qo(psi(:,timepoint),dim);
% repsi=ptrace(psiqo,2);
% M=wfunc(repsi,xvec,yvec);
% figure
% contourf(M);
% end

    