%main, solving the cavity - mirror stochastic schrodinger eq. @copyright Ver 1.00
clear all
global G r wm
tic;
point=1000;
rep=50;
wm=1;
wa=0;
G=0;
r=5;
cutoff1=10;
cutoff2=10;


% m=1e-10;
% gam=0.0002;
% k=1.38e-23;
% h=6.626e-34;
% T=300;
% Re=m*gam*k*T*r/h;
% Im=-1i*m*gam*r*r/2;

t0=0;
tf=5;
dt=(tf-t0)/point;
tspan=linspace(t0,tf,point);


I1=eye(cutoff1);
I2=eye(cutoff2);
I=kron(I1,I2);
a1=destroy(cutoff1);
temp=zeros(cutoff1,cutoff1);
temp(:)=a1.data(:);
a1=temp;
a1=kron(a1,I2);

a2=destroy(cutoff2);
temp=zeros(cutoff2,cutoff2);
temp(:)=a2.data(:);
a2=temp;
a2=kron(I1,a2);

a1d=a1';
a2d=a2';

x2=(a2+a2d)/sqrt(2);
p2=-1i*(a2-a2d)/sqrt(2);
% Hs=a1d*a1;
Hs=wa*a1d*a1+wm*(x2*x2+p2*p2)+G*x2*a1d*a1;
L=x2;
O1=x2;
O2=p2;
O3=a1d*a1;
O4=kron(I1,I2);


%%%%% initial state %%%%%
fai10=zeros(cutoff1,1);
fai20=zeros(cutoff2,1);
fai10(1)=1/sqrt(2);
fai10(2)=1/sqrt(2);
fai20(1)=1/sqrt(2);
fai20(2)=1/sqrt(2);


fai0=kron(fai10,fai20);

% %----using O-U noise
CF=zeros(point,point);
for m=1:point
    t=t0+(m-1)*dt;
    for n=1:point
       s=(n-1)*dt;
       CF(m,n)=(r/2)*exp(-r*abs(t-s));
    end
    CFt(m)=CF(m,1);
end


ini_y=[0;0;0;0];
[t,y]=ode45('cavmirror_ODE1',tspan,ini_y);
FA=y(:,1);
FB=y(:,2);
FC=y(:,3);
J=y(:,4);

Jts=zeros(point,point);
Jtstest=zeros(point,1);
for m=1:point
    Jts(m,m)=-FB(m);
end

for m=2:point
    for n=1:m-1
        dJts=-r*Jts(m-1,n)-FB(m-1)*Jts(m-1,n);
        Jts(m,n)=Jts(m-1,n)+dJts*dt;        
    end
    %----Jts
    for k=1:m;
        Jtstest(m)=Jtstest(m)+CF(m,k)*Jts(m,k)*dt;
    end
    
end



psi=zeros(cutoff1*cutoff2,point,rep);


randn('seed',sum(100*clock));
for n=1:rep
%--solving O operator

    Zt=OUN(r,dt,point);
    z=Zt(:,1)+1i*Zt(:,2);

    Jt=zeros(1,point);
%     for k=1:point
%         for l=1:k
%             Jt(k)=Jt(k)+Jts(k,l)*conj(z(l))*dt;
%         end
%     end    

% --solving stochastic schrodinger eq.
    fai=zeros(cutoff1*cutoff2,point);
    fai(:,1)=fai0;
    psi(:,1,n)=fai0;


    V(:,1)=fai0;
    V0=fai0;
    ztu(1)=z(1);
        mL(1)=V0'*L*V0;
        mLd=V0'*L'*V0;
        L_mL=L-mL(1)*kron(I1,I2);
        Ld_mLd=L'-mLd*kron(I1,I2);
        mLO=0;

    for m=2:6
        Obar=FA(m-1)*O1+FB(m-1)*O2+FC(m-1)*O3-1i*Jt(m-1)*O4;
        V(:,m)=((-1i*Hs+ztu(m-1)*L_mL-Ld_mLd*Obar+mLO*kron(I1,I2))*V(:,m-1))*0.2*dt+V(:,m-1);
        fai=V(:,m);
        mL(m)=fai'*L*fai;
        mLd(m)=fai'*L'*fai;
        L_mL=L-mL(m)*kron(I1,I2);
        Ld_mLd=L'-mLd(m)*kron(I1,I2);
        mLO=fai'*(Ld_mLd*Obar)*fai;
        int=0;
        for k=1:m
        int=int+conj(CFt(m-k+1))*mLd(k)*dt;
        end
        ztu(m)=z(m)+int;
    end
    
    V(:,2)=V(:,6);
    psi(:,2,n)=V(:,2);
    mL(2)=mL(6);
    mLd(2)=mL(6);
    mLO(2)=mLO;
    ztu(2)=ztu(6);
%     rho(:,:,2,n)=V(:,2)*V(:,2)';
    
    %%%%%%%%% Eular mid-point %%%%%%%%%%%%%%%%%%%%%%%%%%    
    V(:,1)=V0;
%     rho(:,:,1,n)=V0*V0';
    ztu(1)=z(1);
        mL(1)=V0'*L*V0;
        mLd(1)=V0'*L'*V0;
        mLO(1)=0;
%         L_mL=L-mL(1)*eye(4);
%         Ld_mLd=L'-mLd*eye(4);
%         mLO=0;

    for m=3:point
        Obar_2=FA(m-2)*O1+FB(m-2)*O2+FC(m-2)*O3-1i*Jt(m-2)*O4;
        Obar_1=FA(m-1)*O1+FB(m-1)*O2+FC(m-1)*O3-1i*Jt(m-1)*O4;
        dV_2=(-1i*Hs+ztu(m-2)*(L-mL(m-2)*I)-(L'-mLd(m-2)*I)*Obar_2...
            +mLO(m-2)*I)*V(:,m-2);
        V_1=V(:,m-2)+dt*dV_2;
        dV_1=(-1i*Hs+ztu(m-1)*(L-mL(m-1)*I)-(L'-mLd(m-1)*I)*Obar_1...
            +mLO(m-1)*I)*V_1;
        V(:,m)=V(:,m-2)+2*dt*dV_1;
        %V(:,m)=((-1i*Hs+ztu(m-1)*L-mL(-Ld_mLd*Obar+mLO*eye(4))*V(:,m-1))*dt+V(:,m-1);
        normV(m)=V(:,m)'*V(:,m);
%         V(:,m)=V(:,m)./normV(m);
        Obar=FA(m)*O1+FB(m)*O2+FC(m)*O3-1i*Jt(m)*O4;
        fai=V(:,m);
        mL(m)=fai'*L*fai;
        mLd(m)=fai'*L'*fai;
        mLO(m)=fai'*(L'-mLd(m)*I)*Obar*fai;

        int=0;
        for k=1:m
        int=int+conj(CFt(m-k+1))*mLd(k)*dt;
        end

        ztu(m)=z(m)+int;
        %V(:,m)=V(:,m)/sqrt(normV(m));
        psi(:,m,n)=V(:,m);
%         rho(:,:,m,n)=V(:,m)*V(:,m)';
%         Mo(m)=trace(V(:,m)*V(:,m)');
    end
end

for m=1:point
    rhotemp=zeros(cutoff1*cutoff2,cutoff1*cutoff2);
    for n=1:rep
        temp=psi(:,m,n);
        rhotemp=rhotemp+temp*temp';
    end
%     rho(:,:,m)=rhotemp/rep;
    rho=rhotemp/rep;
%     rhoPT=PT(rho);
%     EV=eig(rhoPT);
%     Neg(m)=0;
%     for k=1:length(EV)
%         if EV(k)<0
%             Neg(m)=Neg(m)+EV(k);
%         end
%     end
%     Neg(m)=-Neg(m);

    a1da1(m)=trace(rho*a1d*a1);
    a2da2(m)=trace(rho*a2d*a2);
    meanx2(m)=trace(rho*x2);
end


figure
plot(tspan,a1da1,'r'); hold on
%plot(tspan,y1,'r--'); hold on
% plot(tspan,Neg,'b'); hold on
plot(tspan,meanx2,'g');
%plot(tspan,y2,'g--'); hold on


toc;